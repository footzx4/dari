# Modules

import tiktok; import proxies; import creator: import account; import time 
  
 import config from "config.json"
# Creating accounts 

from tiktok import accounts 
from account import email, password, username 
from proxies import * 

creator.init(tiktok.com --accounts)
def __accountCreator__:
  x=creator.newAccount(tiktok, email, password, username) 
    x.append()
      x.changeAvatar(RandomPictureNet) 
        x.subTo(MostFolloweds) 
        
  # Sub to your account
  
  def __subBot__   
    if x.banned -> print('account is banned')
    if x.doesNotExist -> print('skipped account')
    
    else: 
      x.subTo(config.acc)
      x.pass&return 
    print('x.followers + 1') 
